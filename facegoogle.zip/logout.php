<?php

//logout.php
// Destroying session

session_destroy();

header('location:index.php');

?>